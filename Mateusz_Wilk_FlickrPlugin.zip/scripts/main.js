
$(document).ready(function(){

    var apiKey = '';

    $('#slider').FlickrPlugin({user_id: '35972709@N03'});

});
